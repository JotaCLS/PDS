public interface Details {
    
    public void showDetails();
}
