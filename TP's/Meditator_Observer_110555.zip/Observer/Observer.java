// Observer interface
interface Observer {
    void update(float temperature, float humidity);
}
