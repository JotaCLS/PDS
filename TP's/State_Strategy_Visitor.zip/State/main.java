public class main {
    public static void main(String[] args) {
        Fan fan = new Fan();
        fan.switchState();
        fan.switchState();
        fan.switchState();
        fan.switchState();
    }
    
}
