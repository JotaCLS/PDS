// Mediator Interface
interface ChatMediator {
    void sendMessage(String message, Colleague colleague);

    void addColleague(Colleague c3);
}
