import java.util.ArrayList;
import java.util.List;

public class Client {
    public static void main(String[] args) {
        // Creating simple tasks
        Employee employee1 = new Employee("John Doe", "Software Developer", 1000);
        Employee employee2 = new Employee("Jane Doe", "Software Developer", 1000);

        // Creating a list of employees
        List<Employee> employees = new ArrayList<>();
        employees.add(employee1);
        employees.add(employee2);

        // Creating a department
        Department department = new Department("Software Development", "New York", employees, null);

        // Creating a list of departments
        List<Department> departments = new ArrayList<>();
        departments.add(department);

        department.showDetails();
    }
}