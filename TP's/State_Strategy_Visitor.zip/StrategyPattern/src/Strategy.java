public interface Strategy {
    public int performOperation(int a, int b);
}
