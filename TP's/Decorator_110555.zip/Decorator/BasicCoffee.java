public class BasicCoffee implements Coffee{

    public double getCost() {
        return 1.00;
    }

    public String getDescription() {
        return "Coffee";
    }

    
}
