public interface Geometric {
    public void accept(InfoVisitor v);
}
