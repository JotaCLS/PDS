
public interface FanState {
    void switchState(Fan fan);   
    
}