public interface InfoVisitor {
    public void visit(Circle c);
    public void visit(Rectangle r);
    public void visit(Triangle t);
}
